// utils/currencyHelper.js
//チップ更新処理（まだ参照まではしてない）

async function updateBalance(userId, field, amount) {
  // 共通処理
}