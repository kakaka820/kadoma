// src/config.ts


//待機時間設定
export const WAIT_TIME_MS = 1500;



//アンティ
export const ANTE = 100;
//JOKERが何回出たら終了か
export const MAX_JOKER_COUNT = 1;
//この得点以下になったら終了
export const MIN_POINTS = 0;
