//ストーリー

//実際のストーリー

import { characters } from './characters';


//
