// src/story/characters.ts
export const characters = [
  { id: 0, name: "先生", description: "背景や性格の詳細", dialogue: ["セリフ1", "セリフ2"], expressions:[{ name: 'normal', image:''},{name:'happy', image: ''}]},
  { id: 1, name: "女子1", description: "背景や性格の詳細", dialogue: ["セリフ1", "セリフ2"] },
  { id: 2, name: "女子2", description: "背景や性格の詳細", dialogue: ["セリフ1", "セリフ2"] },
  { id: 3, name: "女子3", description: "背景や性格の詳細", dialogue: ["セリフ1", "セリフ2"] },
  { id: 4, name: "男子1（委員長）", description: "背景や性格の詳細", dialogue: ["セリフ1", "セリフ2"] },
];
