// server/botPlayer.js
// Bot プレイヤーのAI処理

const { TURN_TIME_LIMIT, BOT_MIN_DELAY_MS, BOT_MAX_DELAY_MS } = require('../../shared/config');
const { rankToValue } = require('../../shared/core/cardValue');
const randomStrategy = require('./strategies/randomStrategy');
const aggressiveStrategy = require('./strategies/aggressiveStrategy');
const passiveStrategy = require('./strategies/passiveStrategy');
const adaptiveStrategy = require('./strategies/adaptiveStrategy');

// Bot戦略の定義
const BOT_STRATEGIES = {
  RANDOM: 'random',      // ランダム選択
  AGGRESSIVE: 'aggressive', // 強気（大きい順）
  PASSIVE: 'passive',    // 弱気（小さい順）
  ADAPTIVE: 'adaptive'   // 適応型（毎セット変更）
};

// 戦略マッピング
const STRATEGY_MAP = {
  [BOT_STRATEGIES.RANDOM]: randomStrategy,
  [BOT_STRATEGIES.AGGRESSIVE]: aggressiveStrategy,
  [BOT_STRATEGIES.PASSIVE]: passiveStrategy,
  [BOT_STRATEGIES.ADAPTIVE]: adaptiveStrategy
};


/**
 * 戦略に基づいてカードを選択
 * @param {Array} hand - 手札
 * @param {number} setTurnIndex - セット内ターン（0-4）
 * @param {string} strategy - Bot戦略
 * @param {number} setNumber - セット番号（0-4）
 * @returns {number} 選択したカードのインデックス
 */
function selectCardByStrategy(hand, setTurnIndex, strategy, gameState = {}) {
  const strategyModule = STRATEGY_MAP[strategy] || randomStrategy;
  return strategyModule.selectCard(hand, setTurnIndex, gameState);
}

/**
 * Bot が自動でカードを選択（遅延あり）
 *  @param {boolean} isProxy - 代理Botかどうか（切断時の代理）
 * @param {Object} io - Socket.IO インスタンス
 * @param {Map} games - ゲーム状態Map
 * @param {string} roomId - 部屋ID
 * @param {number} botIndex - BotのプレイヤーIndex
 * @param {Function} handleRoundEndCallback - ラウンド終了時のコールバック
 */
function botAutoPlay(io, games, roomId, botIndex, handleRoundEndCallback, isProxy = false) {
  const gameState = games.get(roomId);
  if (!gameState) return;

  // すでに選択済みなら無視
  if (gameState.playerSelections[botIndex]) return;

  const player = gameState.players[botIndex];
  const strategy = player.botStrategy || BOT_STRATEGIES.RANDOM;

   
  //player.isProxy も確認（引数より優先）
  const isProxyBot = isProxy || player.isProxy || false;
  

  //セット番号を遅延前に計算
  const setNumber = Math.floor(gameState.turnIndex / 5);

  //人間らしさ演出
  // 代理Botは即座に選択（遅延なし）
  const delay = isProxyBot ? 0 : BOT_MIN_DELAY_MS + Math.floor(Math.random() * (BOT_MAX_DELAY_MS - BOT_MIN_DELAY_MS));

  setTimeout(() => {
    const currentGameState = games.get(roomId);
    if (!currentGameState) return;

    // 再度選択済みチェック
    if (currentGameState.playerSelections[botIndex]) return;

    const hand = currentGameState.hands[botIndex];

    //戦略に基づいて選択
    const cardIndex = selectCardByStrategy(hand, currentGameState.setTurnIndex, strategy, currentGameState);
    if (cardIndex === -1) return;
    const card = hand[cardIndex];

    // カードを場に出す
    hand.splice(cardIndex, 1);
    currentGameState.fieldCards[botIndex] = card;
    currentGameState.playerSelections[botIndex] = true;



    console.log(`[Bot] Player ${botIndex} (${strategy}, proxy: ${isProxyBot}) played:`, card);

    //代理Bot の場合は即座に場札を公開（handleRoundEnd は呼ばない）
  if (isProxyBot) {
    console.log('[Bot] Proxy bot - revealing card immediately');
    
    // 全員に場札を送信（即開示）
    io.to(roomId).emit('turn_update', {
      currentMultiplier: currentGameState.currentMultiplier,
      fieldCards: currentGameState.fieldCards,
      scores: currentGameState.scores,
      playerSelections: currentGameState.playerSelections
    });
    
    // cards_revealed も送信（フロントで表示用）
    currentGameState.players.forEach((player, idx) => {
      io.to(player.id).emit('cards_revealed', {
        fieldCards: currentGameState.fieldCards,
        hand: currentGameState.hands[idx]
      });
    });
    
    //ここで return（handleRoundEnd は呼ばない）
    return;
  }
    
    

    //通常botは全員に通知
    io.to(roomId).emit('card_played', {
      playerIndex: botIndex,
      card,
      fieldCards: currentGameState.fieldCards
    });

    io.to(roomId).emit('turn_update', {
      currentMultiplier: currentGameState.currentMultiplier,
      fieldCards: currentGameState.fieldCards,
      scores: currentGameState.scores,
      playerSelections: currentGameState.playerSelections
    });

    // 全員選択したか確認
    if (currentGameState.playerSelections.every(Boolean)) {
  //cards_revealed を送る
  console.log('[Bot] Normal bot triggered reveal after 1.5s');
  
  currentGameState.players.forEach((player, idx) => {
    io.to(player.id).emit('cards_revealed', {
      fieldCards: currentGameState.fieldCards,
      hand: currentGameState.hands[idx]
    });
  });

  //通常botは1.5ｓ待機
      setTimeout(() => {
  const latestGameState = games.get(roomId);
  if (!latestGameState) return;
  handleRoundEndCallback(io, games, roomId, latestGameState);
}, 1500);
    }
  }, delay);
}

/**
 * Bot プレイヤー情報を生成
 * @param {string} socketId - 仮のSocket ID
 * @param {number} botNumber - Bot番号
 * @returns {Object} Botプレイヤー情報
 *  @param {boolean} isProxy - 代理Botかどうか
 */
function createBotPlayer(socketId, botNumber, strategy = BOT_STRATEGIES.RANDOM, isProxy = false) {
  const strategyNames = {
    [BOT_STRATEGIES.RANDOM]: 'ランダム',
    [BOT_STRATEGIES.AGGRESSIVE]: '強気',
    [BOT_STRATEGIES.PASSIVE]: '弱気',
    [BOT_STRATEGIES.ADAPTIVE]: '適応型'
  };

  return {
    id: socketId,
    name: isProxy ? `代理Bot ${botNumber}` : `Bot ${botNumber} (${strategyNames[strategy]})`,
    isBot: true,
    isProxy: isProxy,
    botStrategy: strategy
  };
}

module.exports = {
  selectCardByStrategy,
  botAutoPlay,
  createBotPlayer,
  BOT_STRATEGIES
};