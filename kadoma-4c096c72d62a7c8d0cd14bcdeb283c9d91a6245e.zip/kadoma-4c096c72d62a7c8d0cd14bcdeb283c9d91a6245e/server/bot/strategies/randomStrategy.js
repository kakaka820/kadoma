// server/bot/strategies/randomStrategy.js
// ランダム戦略：手札からランダムに選択

/**
 * ランダム戦略でカードを選択
 * @param {Array} hand - 手札
 * @param {number} setTurnIndex - セット内ターン（0-4）
 * @param {Object} gameState - ゲーム状態（必要に応じて使用）
 * @returns {number} 選択したカードのインデックス
 */
function selectCard(hand, setTurnIndex, gameState = {}) {
  if (hand.length === 0) return -1;

  // セットの1ターン目はJOKER除外
  let validCards = hand.map((card, idx) => ({ card, idx }));
  
  if (setTurnIndex === 0) {
    validCards = validCards.filter(item => !item.card.rank?.startsWith('JOKER'));
    if (validCards.length === 0) {
      validCards = hand.map((card, idx) => ({ card, idx }));
    }
  }

  // ランダム選択
  const randomIdx = Math.floor(Math.random() * validCards.length);
  return validCards[randomIdx].idx;
}

module.exports = { selectCard };